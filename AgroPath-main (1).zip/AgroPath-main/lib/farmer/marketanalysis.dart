import 'package:flutter/material.dart';

class Marketanalysis extends StatefulWidget {
  const Marketanalysis({super.key});

  @override
  State<Marketanalysis> createState() => _MarketanalysisState();
}

class _MarketanalysisState extends State<Marketanalysis> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}