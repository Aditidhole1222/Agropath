package com.example.agropath

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
